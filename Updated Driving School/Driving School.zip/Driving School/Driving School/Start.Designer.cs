﻿
namespace Driving_School
{
    partial class Start
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel10 = new System.Windows.Forms.Panel();
            this.bookingCalender = new System.Windows.Forms.MonthCalendar();
            this.instructorEmail = new System.Windows.Forms.ComboBox();
            this.ProofOfPayment = new System.Windows.Forms.ComboBox();
            this.comDiscount = new System.Windows.Forms.ComboBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.txtSubtotal = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.instructorFName = new System.Windows.Forms.TextBox();
            this.pack = new System.Windows.Forms.ComboBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.liscenseCode = new System.Windows.Forms.ComboBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.instructorID = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.comStart = new System.Windows.Forms.ComboBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label56 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.txtCID = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txtCFName = new System.Windows.Forms.TextBox();
            this.txtCLName = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.txtCGender = new System.Windows.Forms.TextBox();
            this.txtCPhone = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.txtCEmail = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtCAddress = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.payTotal = new System.Windows.Forms.MaskedTextBox();
            this.paymentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupDataset = new Driving_School.groupDataset();
            this.payFinalDateBooked = new System.Windows.Forms.MaskedTextBox();
            this.payMethodOfPayment = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.payPackageID = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.payLisenceCode = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.payNumberOfLessons = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.payInstructorEmail = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.payInstructorName = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.payInstructorID = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.payClientEmail = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.payClientName = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.payClientID = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.paymentDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pricePanel2 = new System.Windows.Forms.GroupBox();
            this.txtPackPrice = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.packagesDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.packagesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtPackage_ID = new System.Windows.Forms.TextBox();
            this.txtPackLessons = new System.Windows.Forms.TextBox();
            this.txtPackCode = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pricePanel = new System.Windows.Forms.GroupBox();
            this.txtLicPrice = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.licenseDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnLicAdd = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.ManageClientsPanel = new System.Windows.Forms.Panel();
            this.txtCSearch = new System.Windows.Forms.TextBox();
            this.clientDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button7 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.numOfClients = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCCAddress = new System.Windows.Forms.TextBox();
            this.txtCCGender = new System.Windows.Forms.TextBox();
            this.txtCCEmail = new System.Windows.Forms.TextBox();
            this.txtCCLName = new System.Windows.Forms.TextBox();
            this.txtCCFName = new System.Windows.Forms.TextBox();
            this.txtCCID = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtCCPhone = new System.Windows.Forms.MaskedTextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.ManageInstructorPanel = new System.Windows.Forms.Panel();
            this.txtISearch = new System.Windows.Forms.TextBox();
            this.numOfInstructors = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.instructorDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.instructorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtIID = new System.Windows.Forms.TextBox();
            this.txtIFName = new System.Windows.Forms.TextBox();
            this.txtILName = new System.Windows.Forms.TextBox();
            this.txtIPhone = new System.Windows.Forms.MaskedTextBox();
            this.txtIEmail = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtIGender = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtIAddress = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.instructorTableAdapter = new Driving_School.groupDatasetTableAdapters.InstructorTableAdapter();
            this.tableAdapterManager = new Driving_School.groupDatasetTableAdapters.TableAdapterManager();
            this.clientTableAdapter = new Driving_School.groupDatasetTableAdapters.ClientTableAdapter();
            this.licenseTableAdapter = new Driving_School.groupDatasetTableAdapters.LicenseTableAdapter();
            this.packagesTableAdapter = new Driving_School.groupDatasetTableAdapters.PackagesTableAdapter();
            this.paymentTableAdapter = new Driving_School.groupDatasetTableAdapters.PaymentTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paymentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupDataset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentDataGridView)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.pricePanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.packagesDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagesBindingSource)).BeginInit();
            this.panel4.SuspendLayout();
            this.pricePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.licenseDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.licenseBindingSource)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.ManageClientsPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clientDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            this.panel7.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.ManageInstructorPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.instructorDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructorBindingSource)).BeginInit();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1198, 704);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel10);
            this.tabPage1.Controls.Add(this.panel9);
            this.tabPage1.Location = new System.Drawing.Point(4, 31);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1190, 669);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Manage Bookings";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.bookingCalender);
            this.panel10.Controls.Add(this.instructorEmail);
            this.panel10.Controls.Add(this.ProofOfPayment);
            this.panel10.Controls.Add(this.comDiscount);
            this.panel10.Controls.Add(this.txtTotal);
            this.panel10.Controls.Add(this.button14);
            this.panel10.Controls.Add(this.button13);
            this.panel10.Controls.Add(this.button1);
            this.panel10.Controls.Add(this.button12);
            this.panel10.Controls.Add(this.txtSubtotal);
            this.panel10.Controls.Add(this.label65);
            this.panel10.Controls.Add(this.label68);
            this.panel10.Controls.Add(this.label23);
            this.panel10.Controls.Add(this.label67);
            this.panel10.Controls.Add(this.label66);
            this.panel10.Controls.Add(this.instructorFName);
            this.panel10.Controls.Add(this.pack);
            this.panel10.Controls.Add(this.label64);
            this.panel10.Controls.Add(this.label55);
            this.panel10.Controls.Add(this.liscenseCode);
            this.panel10.Controls.Add(this.label57);
            this.panel10.Controls.Add(this.label63);
            this.panel10.Controls.Add(this.instructorID);
            this.panel10.Controls.Add(this.label58);
            this.panel10.Controls.Add(this.label59);
            this.panel10.Controls.Add(this.comStart);
            this.panel10.Location = new System.Drawing.Point(431, 33);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(742, 584);
            this.panel10.TabIndex = 44;
            this.panel10.Paint += new System.Windows.Forms.PaintEventHandler(this.panel10_Paint);
            // 
            // bookingCalender
            // 
            this.bookingCalender.FirstDayOfWeek = System.Windows.Forms.Day.Monday;
            this.bookingCalender.Location = new System.Drawing.Point(21, 129);
            this.bookingCalender.Name = "bookingCalender";
            this.bookingCalender.ShowTodayCircle = false;
            this.bookingCalender.ShowWeekNumbers = true;
            this.bookingCalender.TabIndex = 44;
            this.bookingCalender.TrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bookingCalender.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.bookingCalender_DateChanged);
            // 
            // instructorEmail
            // 
            this.instructorEmail.FormattingEnabled = true;
            this.instructorEmail.Location = new System.Drawing.Point(14, 40);
            this.instructorEmail.Name = "instructorEmail";
            this.instructorEmail.Size = new System.Drawing.Size(257, 30);
            this.instructorEmail.TabIndex = 43;
            this.instructorEmail.SelectedIndexChanged += new System.EventHandler(this.instructorEmail_SelectedIndexChanged);
            // 
            // ProofOfPayment
            // 
            this.ProofOfPayment.FormattingEnabled = true;
            this.ProofOfPayment.Items.AddRange(new object[] {
            "CASH",
            "CARD",
            "EFT"});
            this.ProofOfPayment.Location = new System.Drawing.Point(14, 329);
            this.ProofOfPayment.Name = "ProofOfPayment";
            this.ProofOfPayment.Size = new System.Drawing.Size(315, 30);
            this.ProofOfPayment.TabIndex = 42;
            // 
            // comDiscount
            // 
            this.comDiscount.FormattingEnabled = true;
            this.comDiscount.Items.AddRange(new object[] {
            "50",
            "100",
            "150",
            "200"});
            this.comDiscount.Location = new System.Drawing.Point(16, 394);
            this.comDiscount.Name = "comDiscount";
            this.comDiscount.Size = new System.Drawing.Size(315, 30);
            this.comDiscount.TabIndex = 42;
            this.comDiscount.Text = "0";
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(366, 395);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(313, 29);
            this.txtTotal.TabIndex = 24;
            this.txtTotal.Text = "0";
            // 
            // button14
            // 
            this.button14.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button14.FlatAppearance.BorderSize = 2;
            this.button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(477, 474);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(194, 42);
            this.button14.TabIndex = 18;
            this.button14.Text = "VIEW BOOKINGS";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button13.FlatAppearance.BorderSize = 2;
            this.button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(77, 474);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(194, 42);
            this.button13.TabIndex = 18;
            this.button13.Text = "CONFIRM BOOKING";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(277, 522);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(194, 42);
            this.button1.TabIndex = 18;
            this.button1.Text = "CLEAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button12
            // 
            this.button12.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button12.FlatAppearance.BorderSize = 2;
            this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(277, 474);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(194, 42);
            this.button12.TabIndex = 18;
            this.button12.Text = "CALCULATE";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // txtSubtotal
            // 
            this.txtSubtotal.Location = new System.Drawing.Point(366, 330);
            this.txtSubtotal.Name = "txtSubtotal";
            this.txtSubtotal.ReadOnly = true;
            this.txtSubtotal.Size = new System.Drawing.Size(313, 29);
            this.txtSubtotal.TabIndex = 34;
            this.txtSubtotal.Text = "0";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(310, 173);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(62, 22);
            this.label65.TabIndex = 41;
            this.label65.Text = "Lessons";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(365, 370);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(111, 22);
            this.label68.TabIndex = 32;
            this.label68.Text = "Total (incl. tax)";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(15, 304);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(150, 22);
            this.label23.TabIndex = 32;
            this.label23.Text = "Method Of Payment";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(365, 305);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(136, 22);
            this.label67.TabIndex = 32;
            this.label67.Text = "Subtotal (excl. tax)";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(17, 369);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(70, 22);
            this.label66.TabIndex = 32;
            this.label66.Text = "Discount";
            // 
            // instructorFName
            // 
            this.instructorFName.Location = new System.Drawing.Point(508, 41);
            this.instructorFName.Name = "instructorFName";
            this.instructorFName.ReadOnly = true;
            this.instructorFName.Size = new System.Drawing.Size(216, 29);
            this.instructorFName.TabIndex = 16;
            // 
            // pack
            // 
            this.pack.FormattingEnabled = true;
            this.pack.Items.AddRange(new object[] {
            "5",
            "10",
            "15",
            "20"});
            this.pack.Location = new System.Drawing.Point(314, 198);
            this.pack.Name = "pack";
            this.pack.Size = new System.Drawing.Size(138, 30);
            this.pack.TabIndex = 39;
            this.pack.SelectedIndexChanged += new System.EventHandler(this.pack_SelectedIndexChanged);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(504, 173);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(45, 22);
            this.label64.TabIndex = 40;
            this.label64.Text = "Code";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(502, 15);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(86, 22);
            this.label55.TabIndex = 15;
            this.label55.Text = "First Name";
            // 
            // liscenseCode
            // 
            this.liscenseCode.FormattingEnabled = true;
            this.liscenseCode.Items.AddRange(new object[] {
            "8",
            "10"});
            this.liscenseCode.Location = new System.Drawing.Point(508, 198);
            this.liscenseCode.Name = "liscenseCode";
            this.liscenseCode.Size = new System.Drawing.Size(138, 30);
            this.liscenseCode.TabIndex = 38;
            this.liscenseCode.SelectedIndexChanged += new System.EventHandler(this.liscenseCode_SelectedIndexChanged);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(273, 15);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(93, 22);
            this.label57.TabIndex = 20;
            this.label57.Text = "InstructorID";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(10, 97);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(103, 22);
            this.label63.TabIndex = 36;
            this.label63.Text = "Booking Date";
            // 
            // instructorID
            // 
            this.instructorID.Location = new System.Drawing.Point(277, 41);
            this.instructorID.Name = "instructorID";
            this.instructorID.ReadOnly = true;
            this.instructorID.Size = new System.Drawing.Size(225, 29);
            this.instructorID.TabIndex = 21;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(10, 15);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(50, 22);
            this.label58.TabIndex = 22;
            this.label58.Text = "Email";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(310, 104);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(81, 22);
            this.label59.TabIndex = 28;
            this.label59.Text = "Start Time";
            // 
            // comStart
            // 
            this.comStart.FormattingEnabled = true;
            this.comStart.Items.AddRange(new object[] {
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14"});
            this.comStart.Location = new System.Drawing.Point(312, 129);
            this.comStart.Name = "comStart";
            this.comStart.Size = new System.Drawing.Size(140, 30);
            this.comStart.TabIndex = 26;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.label56);
            this.panel9.Controls.Add(this.button11);
            this.panel9.Controls.Add(this.button10);
            this.panel9.Controls.Add(this.txtCID);
            this.panel9.Controls.Add(this.label49);
            this.panel9.Controls.Add(this.txtCFName);
            this.panel9.Controls.Add(this.txtCLName);
            this.panel9.Controls.Add(this.label50);
            this.panel9.Controls.Add(this.txtCGender);
            this.panel9.Controls.Add(this.txtCPhone);
            this.panel9.Controls.Add(this.label51);
            this.panel9.Controls.Add(this.label52);
            this.panel9.Controls.Add(this.txtCEmail);
            this.panel9.Controls.Add(this.label53);
            this.panel9.Controls.Add(this.txtCAddress);
            this.panel9.Controls.Add(this.label54);
            this.panel9.Location = new System.Drawing.Point(42, 10);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(365, 655);
            this.panel9.TabIndex = 43;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(14, 9);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(67, 22);
            this.label56.TabIndex = 18;
            this.label56.Text = "ClientID";
            // 
            // button11
            // 
            this.button11.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button11.FlatAppearance.BorderSize = 2;
            this.button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(23, 576);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(312, 51);
            this.button11.TabIndex = 18;
            this.button11.Text = "REGISTER";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button10.FlatAppearance.BorderSize = 2;
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(23, 519);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(312, 51);
            this.button10.TabIndex = 18;
            this.button10.Text = "SEARCH";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // txtCID
            // 
            this.txtCID.Location = new System.Drawing.Point(21, 34);
            this.txtCID.Name = "txtCID";
            this.txtCID.ReadOnly = true;
            this.txtCID.Size = new System.Drawing.Size(313, 29);
            this.txtCID.TabIndex = 17;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(18, 81);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(86, 22);
            this.label49.TabIndex = 8;
            this.label49.Text = "First Name";
            // 
            // txtCFName
            // 
            this.txtCFName.Location = new System.Drawing.Point(21, 106);
            this.txtCFName.Name = "txtCFName";
            this.txtCFName.ReadOnly = true;
            this.txtCFName.Size = new System.Drawing.Size(313, 29);
            this.txtCFName.TabIndex = 4;
            // 
            // txtCLName
            // 
            this.txtCLName.Location = new System.Drawing.Point(21, 175);
            this.txtCLName.Name = "txtCLName";
            this.txtCLName.ReadOnly = true;
            this.txtCLName.Size = new System.Drawing.Size(313, 29);
            this.txtCLName.TabIndex = 3;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(17, 150);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(85, 22);
            this.label50.TabIndex = 9;
            this.label50.Text = "Last Name";
            // 
            // txtCGender
            // 
            this.txtCGender.Location = new System.Drawing.Point(21, 310);
            this.txtCGender.Name = "txtCGender";
            this.txtCGender.ReadOnly = true;
            this.txtCGender.Size = new System.Drawing.Size(313, 29);
            this.txtCGender.TabIndex = 2;
            // 
            // txtCPhone
            // 
            this.txtCPhone.Location = new System.Drawing.Point(21, 246);
            this.txtCPhone.Name = "txtCPhone";
            this.txtCPhone.ReadOnly = true;
            this.txtCPhone.Size = new System.Drawing.Size(313, 29);
            this.txtCPhone.TabIndex = 2;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(17, 221);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(53, 22);
            this.label51.TabIndex = 10;
            this.label51.Text = "Phone";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(17, 285);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(60, 22);
            this.label52.TabIndex = 11;
            this.label52.Text = "Gender";
            // 
            // txtCEmail
            // 
            this.txtCEmail.Location = new System.Drawing.Point(21, 377);
            this.txtCEmail.Name = "txtCEmail";
            this.txtCEmail.Size = new System.Drawing.Size(313, 29);
            this.txtCEmail.TabIndex = 6;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(17, 352);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(50, 22);
            this.label53.TabIndex = 13;
            this.label53.Text = "Email";
            // 
            // txtCAddress
            // 
            this.txtCAddress.Location = new System.Drawing.Point(22, 436);
            this.txtCAddress.Multiline = true;
            this.txtCAddress.Name = "txtCAddress";
            this.txtCAddress.ReadOnly = true;
            this.txtCAddress.Size = new System.Drawing.Size(313, 67);
            this.txtCAddress.TabIndex = 7;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(18, 411);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(64, 22);
            this.label54.TabIndex = 14;
            this.label54.Text = "Address";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.payTotal);
            this.tabPage2.Controls.Add(this.payFinalDateBooked);
            this.tabPage2.Controls.Add(this.payMethodOfPayment);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.payPackageID);
            this.tabPage2.Controls.Add(this.label32);
            this.tabPage2.Controls.Add(this.payLisenceCode);
            this.tabPage2.Controls.Add(this.label36);
            this.tabPage2.Controls.Add(this.label31);
            this.tabPage2.Controls.Add(this.label35);
            this.tabPage2.Controls.Add(this.payNumberOfLessons);
            this.tabPage2.Controls.Add(this.label34);
            this.tabPage2.Controls.Add(this.label33);
            this.tabPage2.Controls.Add(this.payInstructorEmail);
            this.tabPage2.Controls.Add(this.label30);
            this.tabPage2.Controls.Add(this.payInstructorName);
            this.tabPage2.Controls.Add(this.label29);
            this.tabPage2.Controls.Add(this.payInstructorID);
            this.tabPage2.Controls.Add(this.label28);
            this.tabPage2.Controls.Add(this.payClientEmail);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Controls.Add(this.payClientName);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.payClientID);
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.paymentDataGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 31);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1190, 669);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Payments";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // payTotal
            // 
            this.payTotal.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paymentBindingSource, "amount_due", true));
            this.payTotal.Location = new System.Drawing.Point(927, 543);
            this.payTotal.Name = "payTotal";
            this.payTotal.Size = new System.Drawing.Size(219, 29);
            this.payTotal.TabIndex = 6;
            // 
            // paymentBindingSource
            // 
            this.paymentBindingSource.DataMember = "Payment";
            this.paymentBindingSource.DataSource = this.groupDataset;
            // 
            // groupDataset
            // 
            this.groupDataset.DataSetName = "groupDataset";
            this.groupDataset.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // payFinalDateBooked
            // 
            this.payFinalDateBooked.BackColor = System.Drawing.Color.White;
            this.payFinalDateBooked.ForeColor = System.Drawing.Color.Black;
            this.payFinalDateBooked.Location = new System.Drawing.Point(927, 450);
            this.payFinalDateBooked.Mask = "0000/00/00";
            this.payFinalDateBooked.Name = "payFinalDateBooked";
            this.payFinalDateBooked.ReadOnly = true;
            this.payFinalDateBooked.Size = new System.Drawing.Size(219, 29);
            this.payFinalDateBooked.TabIndex = 5;
            this.payFinalDateBooked.ValidatingType = typeof(System.DateTime);
            // 
            // payMethodOfPayment
            // 
            this.payMethodOfPayment.BackColor = System.Drawing.Color.White;
            this.payMethodOfPayment.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paymentBindingSource, "paument_methods", true));
            this.payMethodOfPayment.ForeColor = System.Drawing.Color.Black;
            this.payMethodOfPayment.Location = new System.Drawing.Point(927, 496);
            this.payMethodOfPayment.Name = "payMethodOfPayment";
            this.payMethodOfPayment.ReadOnly = true;
            this.payMethodOfPayment.Size = new System.Drawing.Size(219, 29);
            this.payMethodOfPayment.TabIndex = 4;
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button6.FlatAppearance.BorderSize = 2;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(816, 597);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(330, 40);
            this.button6.TabIndex = 3;
            this.button6.Text = "REFRESH";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            this.button6.ChangeUICues += new System.Windows.Forms.UICuesEventHandler(this.button6_ChangeUICues);
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button5.FlatAppearance.BorderSize = 2;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(816, 35);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(330, 40);
            this.button5.TabIndex = 3;
            this.button5.Text = "VIEW MORE PAYMENT DETAILS";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // payPackageID
            // 
            this.payPackageID.BackColor = System.Drawing.Color.White;
            this.payPackageID.ForeColor = System.Drawing.Color.Black;
            this.payPackageID.Location = new System.Drawing.Point(1066, 358);
            this.payPackageID.Name = "payPackageID";
            this.payPackageID.ReadOnly = true;
            this.payPackageID.Size = new System.Drawing.Size(80, 29);
            this.payPackageID.TabIndex = 2;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(986, 361);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(64, 22);
            this.label32.TabIndex = 1;
            this.label32.Text = "Pack ID";
            // 
            // payLisenceCode
            // 
            this.payLisenceCode.BackColor = System.Drawing.Color.White;
            this.payLisenceCode.ForeColor = System.Drawing.Color.Black;
            this.payLisenceCode.Location = new System.Drawing.Point(901, 358);
            this.payLisenceCode.Name = "payLisenceCode";
            this.payLisenceCode.ReadOnly = true;
            this.payLisenceCode.Size = new System.Drawing.Size(80, 29);
            this.payLisenceCode.TabIndex = 2;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(873, 546);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(44, 22);
            this.label36.TabIndex = 1;
            this.label36.Text = "Total";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(821, 361);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(70, 22);
            this.label31.TabIndex = 1;
            this.label31.Text = "Lic Code";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(873, 499);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(48, 22);
            this.label35.TabIndex = 1;
            this.label35.Text = "MOP";
            // 
            // payNumberOfLessons
            // 
            this.payNumberOfLessons.BackColor = System.Drawing.Color.White;
            this.payNumberOfLessons.ForeColor = System.Drawing.Color.Black;
            this.payNumberOfLessons.Location = new System.Drawing.Point(927, 402);
            this.payNumberOfLessons.Name = "payNumberOfLessons";
            this.payNumberOfLessons.ReadOnly = true;
            this.payNumberOfLessons.Size = new System.Drawing.Size(219, 29);
            this.payNumberOfLessons.TabIndex = 2;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(787, 453);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(130, 22);
            this.label34.TabIndex = 1;
            this.label34.Text = "Last Booked Date";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(855, 405);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(62, 22);
            this.label33.TabIndex = 1;
            this.label33.Text = "Lessons";
            // 
            // payInstructorEmail
            // 
            this.payInstructorEmail.BackColor = System.Drawing.Color.White;
            this.payInstructorEmail.ForeColor = System.Drawing.Color.Black;
            this.payInstructorEmail.Location = new System.Drawing.Point(927, 311);
            this.payInstructorEmail.Name = "payInstructorEmail";
            this.payInstructorEmail.ReadOnly = true;
            this.payInstructorEmail.Size = new System.Drawing.Size(219, 29);
            this.payInstructorEmail.TabIndex = 2;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(798, 314);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(120, 22);
            this.label30.TabIndex = 1;
            this.label30.Text = "Instructor Email";
            // 
            // payInstructorName
            // 
            this.payInstructorName.BackColor = System.Drawing.Color.White;
            this.payInstructorName.ForeColor = System.Drawing.Color.Black;
            this.payInstructorName.Location = new System.Drawing.Point(927, 266);
            this.payInstructorName.Name = "payInstructorName";
            this.payInstructorName.ReadOnly = true;
            this.payInstructorName.Size = new System.Drawing.Size(219, 29);
            this.payInstructorName.TabIndex = 2;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(798, 269);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(122, 22);
            this.label29.TabIndex = 1;
            this.label29.Text = "Instructor Name";
            // 
            // payInstructorID
            // 
            this.payInstructorID.BackColor = System.Drawing.Color.White;
            this.payInstructorID.ForeColor = System.Drawing.Color.Black;
            this.payInstructorID.Location = new System.Drawing.Point(927, 219);
            this.payInstructorID.Name = "payInstructorID";
            this.payInstructorID.ReadOnly = true;
            this.payInstructorID.Size = new System.Drawing.Size(219, 29);
            this.payInstructorID.TabIndex = 2;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(823, 222);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(97, 22);
            this.label28.TabIndex = 1;
            this.label28.Text = "Instructor ID";
            // 
            // payClientEmail
            // 
            this.payClientEmail.BackColor = System.Drawing.Color.White;
            this.payClientEmail.ForeColor = System.Drawing.Color.Black;
            this.payClientEmail.Location = new System.Drawing.Point(927, 172);
            this.payClientEmail.Name = "payClientEmail";
            this.payClientEmail.ReadOnly = true;
            this.payClientEmail.Size = new System.Drawing.Size(219, 29);
            this.payClientEmail.TabIndex = 2;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(827, 175);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(94, 22);
            this.label27.TabIndex = 1;
            this.label27.Text = "Client Email";
            // 
            // payClientName
            // 
            this.payClientName.BackColor = System.Drawing.Color.White;
            this.payClientName.ForeColor = System.Drawing.Color.Black;
            this.payClientName.Location = new System.Drawing.Point(927, 125);
            this.payClientName.Name = "payClientName";
            this.payClientName.ReadOnly = true;
            this.payClientName.Size = new System.Drawing.Size(219, 29);
            this.payClientName.TabIndex = 2;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(825, 128);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(96, 22);
            this.label26.TabIndex = 1;
            this.label26.Text = "Client Name";
            // 
            // payClientID
            // 
            this.payClientID.BackColor = System.Drawing.Color.White;
            this.payClientID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paymentBindingSource, "client_id", true));
            this.payClientID.ForeColor = System.Drawing.Color.Black;
            this.payClientID.Location = new System.Drawing.Point(927, 81);
            this.payClientID.Name = "payClientID";
            this.payClientID.ReadOnly = true;
            this.payClientID.Size = new System.Drawing.Size(219, 29);
            this.payClientID.TabIndex = 2;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(850, 84);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(71, 22);
            this.label25.TabIndex = 1;
            this.label25.Text = "Client ID";
            // 
            // paymentDataGridView
            // 
            this.paymentDataGridView.AllowUserToAddRows = false;
            this.paymentDataGridView.AllowUserToDeleteRows = false;
            this.paymentDataGridView.AllowUserToResizeColumns = false;
            this.paymentDataGridView.AllowUserToResizeRows = false;
            this.paymentDataGridView.AutoGenerateColumns = false;
            this.paymentDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.paymentDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.paymentDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.paymentDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28});
            this.paymentDataGridView.DataSource = this.paymentBindingSource;
            this.paymentDataGridView.Location = new System.Drawing.Point(26, 35);
            this.paymentDataGridView.Name = "paymentDataGridView";
            this.paymentDataGridView.Size = new System.Drawing.Size(749, 615);
            this.paymentDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "payment_id";
            this.dataGridViewTextBoxColumn23.HeaderText = "payment_id";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "booking_id";
            this.dataGridViewTextBoxColumn24.HeaderText = "booking_id";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "client_id";
            this.dataGridViewTextBoxColumn25.HeaderText = "client_id";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "pay_date";
            this.dataGridViewTextBoxColumn26.HeaderText = "pay_date";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "amount_due";
            this.dataGridViewTextBoxColumn27.HeaderText = "amount_due";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "paument_methods";
            this.dataGridViewTextBoxColumn28.HeaderText = "paument_methods";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel1);
            this.tabPage3.Location = new System.Drawing.Point(4, 31);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1190, 669);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "License";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1190, 669);
            this.panel1.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.pricePanel2);
            this.panel5.Controls.Add(this.packagesDataGridView);
            this.panel5.Controls.Add(this.txtPackage_ID);
            this.panel5.Controls.Add(this.txtPackLessons);
            this.panel5.Controls.Add(this.txtPackCode);
            this.panel5.Controls.Add(this.label21);
            this.panel5.Controls.Add(this.button8);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Controls.Add(this.label22);
            this.panel5.Controls.Add(this.label20);
            this.panel5.Location = new System.Drawing.Point(408, 30);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(766, 625);
            this.panel5.TabIndex = 3;
            // 
            // pricePanel2
            // 
            this.pricePanel2.Controls.Add(this.txtPackPrice);
            this.pricePanel2.Controls.Add(this.label17);
            this.pricePanel2.Location = new System.Drawing.Point(388, 464);
            this.pricePanel2.Name = "pricePanel2";
            this.pricePanel2.Size = new System.Drawing.Size(342, 82);
            this.pricePanel2.TabIndex = 13;
            this.pricePanel2.TabStop = false;
            this.pricePanel2.Text = "Update Package Price";
            this.pricePanel2.Visible = false;
            // 
            // txtPackPrice
            // 
            this.txtPackPrice.Location = new System.Drawing.Point(119, 38);
            this.txtPackPrice.Name = "txtPackPrice";
            this.txtPackPrice.Size = new System.Drawing.Size(217, 29);
            this.txtPackPrice.TabIndex = 2;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 38);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 22);
            this.label17.TabIndex = 4;
            this.label17.Text = "Price";
            // 
            // packagesDataGridView
            // 
            this.packagesDataGridView.AutoGenerateColumns = false;
            this.packagesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.packagesDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.packagesDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.packagesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.packagesDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22});
            this.packagesDataGridView.DataSource = this.packagesBindingSource;
            this.packagesDataGridView.Location = new System.Drawing.Point(23, 105);
            this.packagesDataGridView.Name = "packagesDataGridView";
            this.packagesDataGridView.Size = new System.Drawing.Size(716, 316);
            this.packagesDataGridView.TabIndex = 12;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "package_id";
            this.dataGridViewTextBoxColumn19.HeaderText = "package_id";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "lic_code";
            this.dataGridViewTextBoxColumn20.HeaderText = "lic_code";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "number_of_lessons";
            this.dataGridViewTextBoxColumn21.HeaderText = "number_of_lessons";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "price";
            this.dataGridViewTextBoxColumn22.HeaderText = "price";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // packagesBindingSource
            // 
            this.packagesBindingSource.DataMember = "Packages";
            this.packagesBindingSource.DataSource = this.groupDataset;
            // 
            // txtPackage_ID
            // 
            this.txtPackage_ID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.packagesBindingSource, "package_id", true));
            this.txtPackage_ID.Location = new System.Drawing.Point(134, 438);
            this.txtPackage_ID.Name = "txtPackage_ID";
            this.txtPackage_ID.ReadOnly = true;
            this.txtPackage_ID.Size = new System.Drawing.Size(223, 29);
            this.txtPackage_ID.TabIndex = 6;
            // 
            // txtPackLessons
            // 
            this.txtPackLessons.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.packagesBindingSource, "number_of_lessons", true));
            this.txtPackLessons.Location = new System.Drawing.Point(134, 508);
            this.txtPackLessons.Name = "txtPackLessons";
            this.txtPackLessons.ReadOnly = true;
            this.txtPackLessons.Size = new System.Drawing.Size(223, 29);
            this.txtPackLessons.TabIndex = 6;
            // 
            // txtPackCode
            // 
            this.txtPackCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.packagesBindingSource, "lic_code", true));
            this.txtPackCode.Location = new System.Drawing.Point(134, 473);
            this.txtPackCode.Name = "txtPackCode";
            this.txtPackCode.ReadOnly = true;
            this.txtPackCode.Size = new System.Drawing.Size(223, 29);
            this.txtPackCode.TabIndex = 6;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(316, 17);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(131, 28);
            this.label21.TabIndex = 4;
            this.label21.Text = "PACKAGES";
            // 
            // button8
            // 
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button8.FlatAppearance.BorderSize = 2;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(150, 559);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(491, 42);
            this.button8.TabIndex = 3;
            this.button8.Text = "UPDATE";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(66, 511);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(62, 22);
            this.label18.TabIndex = 4;
            this.label18.Text = "Lessons";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(40, 445);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(88, 22);
            this.label22.TabIndex = 4;
            this.label22.Text = "Package ID";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(83, 476);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 22);
            this.label20.TabIndex = 4;
            this.label20.Text = "Code";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.pricePanel);
            this.panel4.Controls.Add(this.licenseDataGridView);
            this.panel4.Controls.Add(this.btnLicAdd);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Location = new System.Drawing.Point(16, 30);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(375, 620);
            this.panel4.TabIndex = 2;
            // 
            // pricePanel
            // 
            this.pricePanel.Controls.Add(this.txtLicPrice);
            this.pricePanel.Controls.Add(this.label19);
            this.pricePanel.Location = new System.Drawing.Point(22, 381);
            this.pricePanel.Name = "pricePanel";
            this.pricePanel.Size = new System.Drawing.Size(312, 86);
            this.pricePanel.TabIndex = 8;
            this.pricePanel.TabStop = false;
            this.pricePanel.Text = "Update Lisence Price";
            this.pricePanel.Visible = false;
            // 
            // txtLicPrice
            // 
            this.txtLicPrice.Location = new System.Drawing.Point(80, 42);
            this.txtLicPrice.Name = "txtLicPrice";
            this.txtLicPrice.Size = new System.Drawing.Size(217, 29);
            this.txtLicPrice.TabIndex = 2;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(11, 45);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 22);
            this.label19.TabIndex = 4;
            this.label19.Text = "Price";
            // 
            // licenseDataGridView
            // 
            this.licenseDataGridView.AutoGenerateColumns = false;
            this.licenseDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.licenseDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.licenseDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.licenseDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.licenseDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            this.licenseDataGridView.DataSource = this.licenseBindingSource;
            this.licenseDataGridView.Location = new System.Drawing.Point(22, 105);
            this.licenseDataGridView.Name = "licenseDataGridView";
            this.licenseDataGridView.Size = new System.Drawing.Size(312, 220);
            this.licenseDataGridView.TabIndex = 6;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "lic_code";
            this.dataGridViewTextBoxColumn17.HeaderText = "lic_code";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "price";
            this.dataGridViewTextBoxColumn18.HeaderText = "price";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // licenseBindingSource
            // 
            this.licenseBindingSource.DataMember = "License";
            this.licenseBindingSource.DataSource = this.groupDataset;
            // 
            // btnLicAdd
            // 
            this.btnLicAdd.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnLicAdd.FlatAppearance.BorderSize = 2;
            this.btnLicAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnLicAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnLicAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLicAdd.Location = new System.Drawing.Point(22, 559);
            this.btnLicAdd.Name = "btnLicAdd";
            this.btnLicAdd.Size = new System.Drawing.Size(312, 42);
            this.btnLicAdd.TabIndex = 3;
            this.btnLicAdd.Text = "UPDATE";
            this.btnLicAdd.UseVisualStyleBackColor = true;
            this.btnLicAdd.Click += new System.EventHandler(this.btnLicAdd_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(107, 17);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(105, 28);
            this.label24.TabIndex = 4;
            this.label24.Text = "LISENCE";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.ManageClientsPanel);
            this.tabPage4.Location = new System.Drawing.Point(4, 31);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1190, 669);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Manage Clients";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // ManageClientsPanel
            // 
            this.ManageClientsPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ManageClientsPanel.Controls.Add(this.txtCSearch);
            this.ManageClientsPanel.Controls.Add(this.clientDataGridView);
            this.ManageClientsPanel.Controls.Add(this.button7);
            this.ManageClientsPanel.Controls.Add(this.button2);
            this.ManageClientsPanel.Controls.Add(this.button3);
            this.ManageClientsPanel.Controls.Add(this.button4);
            this.ManageClientsPanel.Controls.Add(this.label14);
            this.ManageClientsPanel.Controls.Add(this.label13);
            this.ManageClientsPanel.Controls.Add(this.label12);
            this.ManageClientsPanel.Controls.Add(this.label11);
            this.ManageClientsPanel.Controls.Add(this.label10);
            this.ManageClientsPanel.Controls.Add(this.label9);
            this.ManageClientsPanel.Controls.Add(this.numOfClients);
            this.ManageClientsPanel.Controls.Add(this.label15);
            this.ManageClientsPanel.Controls.Add(this.label8);
            this.ManageClientsPanel.Controls.Add(this.txtCCAddress);
            this.ManageClientsPanel.Controls.Add(this.txtCCGender);
            this.ManageClientsPanel.Controls.Add(this.txtCCEmail);
            this.ManageClientsPanel.Controls.Add(this.txtCCLName);
            this.ManageClientsPanel.Controls.Add(this.txtCCFName);
            this.ManageClientsPanel.Controls.Add(this.txtCCID);
            this.ManageClientsPanel.Controls.Add(this.panel7);
            this.ManageClientsPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ManageClientsPanel.Location = new System.Drawing.Point(0, 0);
            this.ManageClientsPanel.Name = "ManageClientsPanel";
            this.ManageClientsPanel.Size = new System.Drawing.Size(1190, 669);
            this.ManageClientsPanel.TabIndex = 0;
            // 
            // txtCSearch
            // 
            this.txtCSearch.Location = new System.Drawing.Point(335, 28);
            this.txtCSearch.Name = "txtCSearch";
            this.txtCSearch.Size = new System.Drawing.Size(293, 29);
            this.txtCSearch.TabIndex = 28;
            this.txtCSearch.TextChanged += new System.EventHandler(this.txtCSearch_TextChanged);
            // 
            // clientDataGridView
            // 
            this.clientDataGridView.AutoGenerateColumns = false;
            this.clientDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.clientDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clientDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.clientDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16});
            this.clientDataGridView.DataSource = this.clientBindingSource;
            this.clientDataGridView.Location = new System.Drawing.Point(40, 79);
            this.clientDataGridView.Name = "clientDataGridView";
            this.clientDataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.clientDataGridView.Size = new System.Drawing.Size(743, 485);
            this.clientDataGridView.TabIndex = 27;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "client_id";
            this.dataGridViewTextBoxColumn9.HeaderText = "client_id";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "first_name";
            this.dataGridViewTextBoxColumn10.HeaderText = "first_name";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "last_name";
            this.dataGridViewTextBoxColumn11.HeaderText = "last_name";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "phone";
            this.dataGridViewTextBoxColumn12.HeaderText = "phone";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "email";
            this.dataGridViewTextBoxColumn13.HeaderText = "email";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "gender";
            this.dataGridViewTextBoxColumn14.HeaderText = "gender";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "client_address";
            this.dataGridViewTextBoxColumn15.HeaderText = "client_address";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "client_password";
            this.dataGridViewTextBoxColumn16.HeaderText = "client_password";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.groupDataset;
            // 
            // button7
            // 
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button7.FlatAppearance.BorderSize = 2;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(583, 585);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(175, 57);
            this.button7.TabIndex = 24;
            this.button7.Text = "VIEW BOOKINGS";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 2;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(402, 585);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(175, 57);
            this.button2.TabIndex = 24;
            this.button2.Text = "REFRESH";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button3.FlatAppearance.BorderSize = 2;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(221, 585);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(175, 57);
            this.button3.TabIndex = 25;
            this.button3.Text = "UPDATE";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button4.FlatAppearance.BorderSize = 2;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(40, 585);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(175, 57);
            this.button4.TabIndex = 26;
            this.button4.Text = "ADD";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(809, 511);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(64, 22);
            this.label14.TabIndex = 18;
            this.label14.Text = "Address";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(809, 443);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 22);
            this.label13.TabIndex = 19;
            this.label13.Text = "Gender";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(809, 375);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 22);
            this.label12.TabIndex = 20;
            this.label12.Text = "Email";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(809, 305);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 22);
            this.label11.TabIndex = 21;
            this.label11.Text = "Phone";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(809, 235);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 22);
            this.label10.TabIndex = 22;
            this.label10.Text = "Last Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(809, 163);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 22);
            this.label9.TabIndex = 17;
            this.label9.Text = "First Name";
            // 
            // numOfClients
            // 
            this.numOfClients.AutoSize = true;
            this.numOfClients.Location = new System.Drawing.Point(982, 31);
            this.numOfClients.Name = "numOfClients";
            this.numOfClients.Size = new System.Drawing.Size(76, 22);
            this.numOfClients.TabIndex = 23;
            this.numOfClients.Text = "Clients : 0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(241, 31);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 22);
            this.label15.TabIndex = 23;
            this.label15.Text = "SEARCH";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(809, 89);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 22);
            this.label8.TabIndex = 23;
            this.label8.Text = "Client ID";
            // 
            // txtCCAddress
            // 
            this.txtCCAddress.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "client_address", true));
            this.txtCCAddress.Location = new System.Drawing.Point(813, 536);
            this.txtCCAddress.Multiline = true;
            this.txtCCAddress.Name = "txtCCAddress";
            this.txtCCAddress.ReadOnly = true;
            this.txtCCAddress.Size = new System.Drawing.Size(313, 106);
            this.txtCCAddress.TabIndex = 13;
            // 
            // txtCCGender
            // 
            this.txtCCGender.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "gender", true));
            this.txtCCGender.Location = new System.Drawing.Point(813, 468);
            this.txtCCGender.Name = "txtCCGender";
            this.txtCCGender.ReadOnly = true;
            this.txtCCGender.Size = new System.Drawing.Size(313, 29);
            this.txtCCGender.TabIndex = 14;
            // 
            // txtCCEmail
            // 
            this.txtCCEmail.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "email", true));
            this.txtCCEmail.Location = new System.Drawing.Point(813, 400);
            this.txtCCEmail.Name = "txtCCEmail";
            this.txtCCEmail.ReadOnly = true;
            this.txtCCEmail.Size = new System.Drawing.Size(313, 29);
            this.txtCCEmail.TabIndex = 15;
            // 
            // txtCCLName
            // 
            this.txtCCLName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "last_name", true));
            this.txtCCLName.Location = new System.Drawing.Point(813, 260);
            this.txtCCLName.Name = "txtCCLName";
            this.txtCCLName.ReadOnly = true;
            this.txtCCLName.Size = new System.Drawing.Size(313, 29);
            this.txtCCLName.TabIndex = 16;
            // 
            // txtCCFName
            // 
            this.txtCCFName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "first_name", true));
            this.txtCCFName.Location = new System.Drawing.Point(813, 188);
            this.txtCCFName.Name = "txtCCFName";
            this.txtCCFName.ReadOnly = true;
            this.txtCCFName.Size = new System.Drawing.Size(313, 29);
            this.txtCCFName.TabIndex = 12;
            // 
            // txtCCID
            // 
            this.txtCCID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "client_id", true));
            this.txtCCID.Location = new System.Drawing.Point(813, 114);
            this.txtCCID.Name = "txtCCID";
            this.txtCCID.ReadOnly = true;
            this.txtCCID.Size = new System.Drawing.Size(313, 29);
            this.txtCCID.TabIndex = 11;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel7.Controls.Add(this.txtCCPhone);
            this.panel7.Location = new System.Drawing.Point(798, 79);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(347, 580);
            this.panel7.TabIndex = 27;
            // 
            // txtCCPhone
            // 
            this.txtCCPhone.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "phone", true));
            this.txtCCPhone.Location = new System.Drawing.Point(13, 249);
            this.txtCCPhone.Mask = "0000000000";
            this.txtCCPhone.Name = "txtCCPhone";
            this.txtCCPhone.ReadOnly = true;
            this.txtCCPhone.Size = new System.Drawing.Size(313, 29);
            this.txtCCPhone.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.ManageInstructorPanel);
            this.tabPage5.Location = new System.Drawing.Point(4, 31);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1190, 669);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Manage Instructor";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // ManageInstructorPanel
            // 
            this.ManageInstructorPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ManageInstructorPanel.Controls.Add(this.txtISearch);
            this.ManageInstructorPanel.Controls.Add(this.numOfInstructors);
            this.ManageInstructorPanel.Controls.Add(this.label16);
            this.ManageInstructorPanel.Controls.Add(this.instructorDataGridView);
            this.ManageInstructorPanel.Controls.Add(this.btnRefresh);
            this.ManageInstructorPanel.Controls.Add(this.btnUpdate);
            this.ManageInstructorPanel.Controls.Add(this.btnAdd);
            this.ManageInstructorPanel.Controls.Add(this.panel6);
            this.ManageInstructorPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ManageInstructorPanel.Location = new System.Drawing.Point(0, 0);
            this.ManageInstructorPanel.Name = "ManageInstructorPanel";
            this.ManageInstructorPanel.Size = new System.Drawing.Size(1190, 669);
            this.ManageInstructorPanel.TabIndex = 0;
            // 
            // txtISearch
            // 
            this.txtISearch.Location = new System.Drawing.Point(293, 29);
            this.txtISearch.Name = "txtISearch";
            this.txtISearch.Size = new System.Drawing.Size(293, 29);
            this.txtISearch.TabIndex = 30;
            this.txtISearch.TextChanged += new System.EventHandler(this.txtISearch_TextChanged);
            // 
            // numOfInstructors
            // 
            this.numOfInstructors.AutoSize = true;
            this.numOfInstructors.Location = new System.Drawing.Point(974, 29);
            this.numOfInstructors.Name = "numOfInstructors";
            this.numOfInstructors.Size = new System.Drawing.Size(102, 22);
            this.numOfInstructors.TabIndex = 29;
            this.numOfInstructors.Text = "Instructors : 0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(199, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(74, 22);
            this.label16.TabIndex = 29;
            this.label16.Text = "SEARCH";
            // 
            // instructorDataGridView
            // 
            this.instructorDataGridView.AutoGenerateColumns = false;
            this.instructorDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.instructorDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.instructorDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.instructorDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.instructorDataGridView.DataSource = this.instructorBindingSource;
            this.instructorDataGridView.Location = new System.Drawing.Point(35, 73);
            this.instructorDataGridView.Name = "instructorDataGridView";
            this.instructorDataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.instructorDataGridView.Size = new System.Drawing.Size(742, 515);
            this.instructorDataGridView.TabIndex = 10;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "inst_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "inst_id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "first_name";
            this.dataGridViewTextBoxColumn2.HeaderText = "first_name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "last_name";
            this.dataGridViewTextBoxColumn3.HeaderText = "last_name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "phone";
            this.dataGridViewTextBoxColumn4.HeaderText = "phone";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "email";
            this.dataGridViewTextBoxColumn5.HeaderText = "email";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "gender";
            this.dataGridViewTextBoxColumn6.HeaderText = "gender";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "inst_address";
            this.dataGridViewTextBoxColumn7.HeaderText = "inst_address";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "inst_password";
            this.dataGridViewTextBoxColumn8.HeaderText = "inst_password";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // instructorBindingSource
            // 
            this.instructorBindingSource.DataMember = "Instructor";
            this.instructorBindingSource.DataSource = this.groupDataset;
            // 
            // btnRefresh
            // 
            this.btnRefresh.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnRefresh.FlatAppearance.BorderSize = 2;
            this.btnRefresh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnRefresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.Location = new System.Drawing.Point(499, 602);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(175, 57);
            this.btnRefresh.TabIndex = 7;
            this.btnRefresh.Text = "REFRESH";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnUpdate.FlatAppearance.BorderSize = 2;
            this.btnUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Location = new System.Drawing.Point(318, 602);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(175, 57);
            this.btnUpdate.TabIndex = 8;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAdd.FlatAppearance.BorderSize = 2;
            this.btnAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Location = new System.Drawing.Point(137, 602);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(175, 57);
            this.btnAdd.TabIndex = 9;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.txtIID);
            this.panel6.Controls.Add(this.txtIFName);
            this.panel6.Controls.Add(this.txtILName);
            this.panel6.Controls.Add(this.txtIPhone);
            this.panel6.Controls.Add(this.txtIEmail);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.txtIGender);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.txtIAddress);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Location = new System.Drawing.Point(798, 58);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(356, 601);
            this.panel6.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Instructor Id";
            // 
            // txtIID
            // 
            this.txtIID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.instructorBindingSource, "inst_id", true));
            this.txtIID.Location = new System.Drawing.Point(24, 38);
            this.txtIID.Name = "txtIID";
            this.txtIID.ReadOnly = true;
            this.txtIID.Size = new System.Drawing.Size(313, 29);
            this.txtIID.TabIndex = 1;
            // 
            // txtIFName
            // 
            this.txtIFName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.instructorBindingSource, "first_name", true));
            this.txtIFName.Location = new System.Drawing.Point(24, 103);
            this.txtIFName.Name = "txtIFName";
            this.txtIFName.ReadOnly = true;
            this.txtIFName.Size = new System.Drawing.Size(313, 29);
            this.txtIFName.TabIndex = 1;
            // 
            // txtILName
            // 
            this.txtILName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.instructorBindingSource, "last_name", true));
            this.txtILName.Location = new System.Drawing.Point(24, 170);
            this.txtILName.Name = "txtILName";
            this.txtILName.ReadOnly = true;
            this.txtILName.Size = new System.Drawing.Size(313, 29);
            this.txtILName.TabIndex = 1;
            // 
            // txtIPhone
            // 
            this.txtIPhone.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.instructorBindingSource, "phone", true));
            this.txtIPhone.Location = new System.Drawing.Point(24, 244);
            this.txtIPhone.Mask = "0000000000";
            this.txtIPhone.Name = "txtIPhone";
            this.txtIPhone.ReadOnly = true;
            this.txtIPhone.Size = new System.Drawing.Size(313, 29);
            this.txtIPhone.TabIndex = 3;
            // 
            // txtIEmail
            // 
            this.txtIEmail.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.instructorBindingSource, "email", true));
            this.txtIEmail.Location = new System.Drawing.Point(24, 318);
            this.txtIEmail.Name = "txtIEmail";
            this.txtIEmail.ReadOnly = true;
            this.txtIEmail.Size = new System.Drawing.Size(313, 29);
            this.txtIEmail.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 437);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 22);
            this.label7.TabIndex = 2;
            this.label7.Text = "Address";
            // 
            // txtIGender
            // 
            this.txtIGender.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.instructorBindingSource, "gender", true));
            this.txtIGender.Location = new System.Drawing.Point(24, 390);
            this.txtIGender.Name = "txtIGender";
            this.txtIGender.ReadOnly = true;
            this.txtIGender.Size = new System.Drawing.Size(313, 29);
            this.txtIGender.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 365);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 22);
            this.label6.TabIndex = 2;
            this.label6.Text = "Gender";
            // 
            // txtIAddress
            // 
            this.txtIAddress.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.instructorBindingSource, "inst_address", true));
            this.txtIAddress.Location = new System.Drawing.Point(24, 462);
            this.txtIAddress.Multiline = true;
            this.txtIAddress.Name = "txtIAddress";
            this.txtIAddress.ReadOnly = true;
            this.txtIAddress.Size = new System.Drawing.Size(313, 105);
            this.txtIAddress.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 293);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 22);
            this.label5.TabIndex = 2;
            this.label5.Text = "Email";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "First Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 219);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 22);
            this.label4.TabIndex = 2;
            this.label4.Text = "Phone";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Last Name";
            // 
            // instructorTableAdapter
            // 
            this.instructorTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BookingTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = this.clientTableAdapter;
            this.tableAdapterManager.InstructorTableAdapter = this.instructorTableAdapter;
            this.tableAdapterManager.LicenseTableAdapter = null;
            this.tableAdapterManager.PackagesTableAdapter = null;
            this.tableAdapterManager.PaymentTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Driving_School.groupDatasetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // licenseTableAdapter
            // 
            this.licenseTableAdapter.ClearBeforeFill = true;
            // 
            // packagesTableAdapter
            // 
            this.packagesTableAdapter.ClearBeforeFill = true;
            // 
            // paymentTableAdapter
            // 
            this.paymentTableAdapter.ClearBeforeFill = true;
            // 
            // Start
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1198, 704);
            this.Controls.Add(this.tabControl1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1218, 747);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1218, 747);
            this.Name = "Start";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MK DRIVING SCHOOL";
            this.Load += new System.EventHandler(this.Start_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paymentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupDataset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentDataGridView)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.pricePanel2.ResumeLayout(false);
            this.pricePanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.packagesDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagesBindingSource)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.pricePanel.ResumeLayout(false);
            this.pricePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.licenseDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.licenseBindingSource)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.ManageClientsPanel.ResumeLayout(false);
            this.ManageClientsPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clientDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.ManageInstructorPanel.ResumeLayout(false);
            this.ManageInstructorPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.instructorDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructorBindingSource)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.ComboBox instructorEmail;
        private System.Windows.Forms.ComboBox ProofOfPayment;
        private System.Windows.Forms.ComboBox comDiscount;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox txtSubtotal;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox instructorFName;
        private System.Windows.Forms.ComboBox pack;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox instructorID;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.ComboBox comStart;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox txtCID;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtCFName;
        private System.Windows.Forms.TextBox txtCLName;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txtCGender;
        private System.Windows.Forms.TextBox txtCPhone;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtCEmail;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtCAddress;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.MonthCalendar bookingCalender;
        private System.Windows.Forms.Panel ManageInstructorPanel;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.ComboBox liscenseCode;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtIID;
        private System.Windows.Forms.TextBox txtIFName;
        private System.Windows.Forms.TextBox txtILName;
        private System.Windows.Forms.MaskedTextBox txtIPhone;
        private System.Windows.Forms.TextBox txtIEmail;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtIGender;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtIAddress;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private groupDataset groupDataset;
        private System.Windows.Forms.BindingSource instructorBindingSource;
        private groupDatasetTableAdapters.InstructorTableAdapter instructorTableAdapter;
        private groupDatasetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView instructorDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.Panel ManageClientsPanel;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCCAddress;
        private System.Windows.Forms.TextBox txtCCGender;
        private System.Windows.Forms.TextBox txtCCEmail;
        private System.Windows.Forms.TextBox txtCCLName;
        private System.Windows.Forms.TextBox txtCCFName;
        private System.Windows.Forms.TextBox txtCCID;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.MaskedTextBox txtCCPhone;
        private groupDatasetTableAdapters.ClientTableAdapter clientTableAdapter;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private System.Windows.Forms.DataGridView clientDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.TextBox txtCSearch;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtISearch;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label numOfClients;
        private System.Windows.Forms.Label numOfInstructors;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtPackage_ID;
        private System.Windows.Forms.TextBox txtPackCode;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtPackPrice;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnLicAdd;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtLicPrice;
        private System.Windows.Forms.BindingSource licenseBindingSource;
        private groupDatasetTableAdapters.LicenseTableAdapter licenseTableAdapter;
        private System.Windows.Forms.DataGridView licenseDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.BindingSource packagesBindingSource;
        private groupDatasetTableAdapters.PackagesTableAdapter packagesTableAdapter;
        private System.Windows.Forms.DataGridView packagesDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox pricePanel2;
        private System.Windows.Forms.GroupBox pricePanel;
        private System.Windows.Forms.TextBox txtPackLessons;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.BindingSource paymentBindingSource;
        private groupDatasetTableAdapters.PaymentTableAdapter paymentTableAdapter;
        private System.Windows.Forms.TextBox payClientID;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.DataGridView paymentDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox payMethodOfPayment;
        private System.Windows.Forms.TextBox payPackageID;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox payLisenceCode;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox payNumberOfLessons;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox payInstructorEmail;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox payInstructorName;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox payInstructorID;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox payClientEmail;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox payClientName;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.MaskedTextBox payFinalDateBooked;
        private System.Windows.Forms.MaskedTextBox payTotal;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
    }
}

